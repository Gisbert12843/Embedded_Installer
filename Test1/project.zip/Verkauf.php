<!DOCTYPE html>
<html lang="en">
<?php
include_once("connection.php");
global $link;




?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Verkauf.css">
    <title>Verkauf</title>
</head>

<body> <div id="global_wrapper">
    <div id="nav_wrapper">
        <nav>
            <a href="index.html"><button id="bt_Auswertung"><img src="./img/auswertung.png">
                Auswertung</button></a>
            <a href="Lager.php"><button id="bt_Lager"><img src="./img/lager.png">Lager</button></a>
            <a href="Lieferanten.html"><button id="bt_Lieferanten"><img
                    src="./img/lieferant.png">Lieferanten</button></a>
            <a href="Einkauf.html"><button id="bt_Einkauf"><img src="./img/price-tag.png">Einkauf</button></a>
            <a href="Verkauf.html"><button id="bt_Verkauf"><img src="./img/shopping-cart.png">Verkauf</button></a>
        </nav>
    </div>

    <div id="content_wrapper">
        <div id="inner_content_wrapper">




            <div id="Verkauf_wrapper">
                <div id="Title_Verkauf_wrapper">
                    <div class="img_wrapper" id="verkaufpng">
                        <img src="./img/shopping-cart.png" alt="">
                    </div>
                    <span><b>Verkauf:</b></span><br>
                    <button class="bt_addnew" id="bt_addnew" onclick="func_addbutton()">
                        <div id="div_addnew">
                            <img src="./img/plus-positive-add-mathematical-symbol.png" alt="">
                            <!-- <input type="button" id="add_button" name="add_button"> -->
                            <div><span>Hinzufügen</span></div>
                        </div>
                    </button>
                </div>
                <div id="adding_wrapper">
                    <div class="firstchild">
                        <div class="img_wrapper" id="verkaufpng">
                            <img src="./img/shopping-cart.png" alt="">
                        </div>
                        <span><b>Verkauf - Hinzufügen:</b></span><br>
                    </div>
                    <div class="secondchild">
                        <div id="input_div">
                            <div>
                                <label for="PID">PID:</label>
                                <input type="text" id="PID" name="PID">
                            </div>
                            <!-- <br> -->
                            <div>
                                <label for="menge">Menge:</label>
                                <input type="text" id="menge" name="menge">

                            </div>
                            <div id="btadd_div">
                                <button class="bt_add" id="bt_add" onclick="func_addbutton_inner()">
                                    <div id="btadd_div_inside">
                                        <img src="./img/plus-positive-add-mathematical-symbol.png" alt="">
                                        <!-- <input type="button" id="add_button" name="add_button"> -->
                                        <div><span>Hinzufügen</span></div>
                                    </div>
                                </button>
                            </div>
                            <div class="break" style="  flex-basis: 100%; height: 0;"></div> <!-- break to a new row -->

                        </div>
                        <span id="PID_warning">PID nicht im Lager eingetragen.!</span>


                        <div id="buttons_div">
                            <button class="bt_abbrechen" id="bt_abbrechen" onclick="func_abbrbutton()">
                                <div id="div_abbrechen">
                                    <img src="./img/cancel-square-button.png" alt="">
                                    <!-- <input type="button" id="add_button" name="add_button"> -->
                                    <div><span>Abbrechen</span></div>
                                </div>
                            </button>
                            <span><b>Summe: 104.00€</b></span>
                            <button class="bt_speichern" id="bt_speichern" onclick="func_speicherbutton()">
                                <div id="div_speichern">
                                    <img src="./img/save.png" alt="">
                                    <!-- <input type="button" id="add_button" name="add_button"> -->
                                    <div><span>Speichern</span></div>
                                </div>
                            </button>
                        </div>
                        <div>
                            <table>
                                <tr>
                                    <th>PID</th>
                                    <th>Produktname</th>
                                    <th>Menge</th>
                                    <th>Verkaufspreis</th>
                                    <th>Zwischensumme</th>

                                </tr>
                                <tr>
                                    <td>81236652</td>
                                    <td>Tomate</td>
                                    <td>20</td>
                                    <td>4.20€</td>
                                    <td>84.00€</td>
                                </tr>
                                <tr>
                                    <td>93827462</td>
                                    <td>Apfel</td>
                                    <td>10</td>
                                    <td>2.00€</td>
                                    <td>20.00€</td>
                                </tr>

                            </table>
                        </div>
                    </div>
                </div>
                <span id="table_caption"><b>Alle Verkäufe</b></span>
                <table id="main_table">
                    <tr>
                        <th></th>
                        <th>VID</th>
                        <th>Datum</th>
                        <th>Gesamtpreis</th>
                    </tr>







                    <?php
                        $sql = "select `Warenkorb-id`,`Datum` from `verkauf/warenkoerbe` where ISDELETE = 0 ORDER BY `Warenkorb-id` DESC";
                        $result = mysqli_query($link, $sql);

                        while ($row = mysqli_fetch_assoc($result)) {
                        $balance = 0;

                        $sqlinner = "select `Ware_has_Verkauf/Warenkoerbe`.`Ware_EID`,Ware.Name,Ware.Verkaufspreis,`Ware_has_Verkauf/Warenkoerbe`.`Menge` from `Ware_has_Verkauf/Warenkoerbe` JOIN `Ware` ON `Ware_has_Verkauf/Warenkoerbe`.`Ware_EID` = `Ware`.`EID` AND `Ware`.`ISDELETE` = 0 Where `Ware_has_Verkauf/Warenkoerbe`.ISDELETE = 0 AND `Ware_has_Verkauf/Warenkoerbe`.`Verkauf/Warenkoerbe_Warenkorb-ID` = ".$row['Warenkorb-id'];
                        $resultinner = mysqli_query($link, $sqlinner);
                            while ($rowinner = mysqli_fetch_assoc($resultinner)){
                                $balance = $balance + ($rowinner['Verkaufspreis'] * $rowinner['Menge']);
                            }




                            echo
                                "<tr class=\"new_tr verspaetet\">".
                    "<td class=\"expander\">▼</td>".
                    "<td>".$row['Warenkorb-id']."</td>".
                    "<td>".$row['Datum']."</td>".
                    "<td>".$balance."€</td>".
                    "</tr>";
                    echo
                    "<tr style=\"display: none\">".
                    "<td></td>".
                    "<td colspan=\"100\">".
                    "<table class=\"expand_table\">".
                        "<tr>".
                            "<th>PID</th>".
                            "<th>Produktname</th>".
                            "<th>Verkaufspreis</th>".
                            "<th>Menge</th>".
                            "<th>Summe</th>".
                            "</tr>";

                        $sqlinner = "select `Ware_has_Verkauf/Warenkoerbe`.`Ware_EID`,Ware.Name,Ware.Verkaufspreis,`Ware_has_Verkauf/Warenkoerbe`.`Menge` from `Ware_has_Verkauf/Warenkoerbe` JOIN `Ware` ON `Ware_has_Verkauf/Warenkoerbe`.`Ware_EID` = `Ware`.`EID` AND `Ware`.`ISDELETE` = 0 Where `Ware_has_Verkauf/Warenkoerbe`.ISDELETE = 0 AND `Ware_has_Verkauf/Warenkoerbe`.`Verkauf/Warenkoerbe_Warenkorb-ID` = ".$row['Warenkorb-id'];
                        $resultinner = mysqli_query($link, $sqlinner);


                        while ($rowinner = mysqli_fetch_assoc($resultinner)) {

                        echo "<tr>".
                            "<td>".$rowinner['Ware_EID']."</td>".
                            "<td>".$rowinner['Name']."</td>".
                            "<td>".$rowinner['Verkaufspreis']."€</td>".
                            "<td>".$rowinner['Menge']."</td>".
                            "<td>".$rowinner['Verkaufspreis'] * $rowinner['Menge']."€</td>".
                            "</tr>";
                        $balance = $balance + ($rowinner['Verkaufspreis'] * $rowinner['Menge']);
                        }

                        mysqli_free_result($resultinner);
                        echo
                        "</table>".
                    "</td>".
                    "</tr>";

                    }
                    ?>
                </table>
            </div>




        </div>
    </div>
</div>

<script type="text/javascript">
    // const table = document.querySelector("table");
    const tablebyid = document.getElementById("main_table");
    tablebyid.addEventListener("click", function (e)
    {
        const td = e.target;
        if (td.classList.contains("expander"))
        {
            const style = td.parentNode.nextElementSibling.style;
            const wasOpen = !style.display;
            console.log(wasOpen);
            style.display = wasOpen ? "none" : "";
            td.textContent = wasOpen ? "▼" : "▲";
        }
    });

    // document.getElementById("bt_addnew").onclick = function () { func_addbutton() };
    function func_addbutton()
    {
        document.getElementById("Title_Verkauf_wrapper").style.display = "none";
        document.getElementById("table_caption").style.display = "none";
        document.getElementById("main_table").style.display = "none";
        document.getElementById("adding_wrapper").style.display = "flex";

    }
    function func_addbutton_inner()
    {
        document.getElementById("Title_Verkauf_wrapper").style.display = "none";
        document.getElementById("table_caption").style.display = "none";
        document.getElementById("main_table").style.display = "none";
        document.getElementById("adding_wrapper").style.display = "flex";
        document.getElementById("PID_warning").style.display = "block";

    }
    // document.getElementById("bt_abbrechen").onclick = function () { func_abbrbutton() };
    function func_abbrbutton()
    {
        document.getElementById("Title_Verkauf_wrapper").style.display = "flex";
        document.getElementById("table_caption").style.display = "";
        document.getElementById("main_table").style.display = "";
        document.getElementById("adding_wrapper").style.display = "none";
        document.getElementById("PID_warning").style.display = "none";

    }
    // document.getElementById("bt_speichern").onclick = function () { func_speicherbutton() };
    function func_speicherbutton()
    {
        document.getElementById("Title_Verkauf_wrapper").style.display = "flex";
        document.getElementById("table_caption").style.display = "";
        document.getElementById("main_table").style.display = "";
        document.getElementById("adding_wrapper").style.display = "none";
        document.getElementById("PID_warning").style.display = "none";

    }

</script>
</body>

</html>