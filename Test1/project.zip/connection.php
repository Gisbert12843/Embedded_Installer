<?php
$link = mysqli_connect(
    "localhost",
    "root",
    "toor",
    "MehrMarktDatabase",
    "3307"
);
if (!$link) {
    echo "Verbindung fehlgeschlagen: ", mysqli_connect_error();
    exit();

}
$link-> set_charset("utf8");

