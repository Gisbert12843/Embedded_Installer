<?php
$link = mysqli_connect(
    "localhost",
    "root",
    "toor",
    "MehrMarktDatabase",
    "42069"
);
if (!$link) {
    echo "Verbindung fehlgeschlagen: ", mysqli_connect_error();
    exit();

}
$link-> set_charset("utf8");

